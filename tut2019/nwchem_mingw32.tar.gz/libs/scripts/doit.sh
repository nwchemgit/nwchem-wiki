make MAYBE_HOST="--host=i686-w64-mingw32.static" CC=i686-w64-mingw32-gcc-win32 FC=i686-w64-mingw32-gfortran-win32

