#!/bin/bash
curl -LJO https://github.com/nwchemgit/nwchem/tarball/hotfix/release-7-0-0
tar xzf nwchemgit-nwchem-v7.0.0-release-*-*.tar.gz
mv nwchemgit-nwchem-??????? nwchem-7.0.1
export NWCHEM_TOP=`pwd`/nwchem-7.0.1 
export LIBS_HOME=`pwd`/libs
cd nwchem-7.0.1/src
  #  source ../../libs/scripts/nwchem.bashrc
export USE_MPI=1
export ARMCI_NETWORK=MPI-TS
export FC=i686-w64-mingw32.static-gfortran
export CC=i686-w64-mingw32.static-gcc
export CXX=i686-w64-mingw32.static-g++
export FC=i686-w64-mingw32-gfortran-win32
export CC=i686-w64-mingw32-gcc-win32
export CXX=i686-w64-mingw32-g++-win32
export NWCHEM_TARGET=LINUX
export USE_INTERNALBLAS=y
#export MPI_INCLUDE="$LIBS_HOME/MPI/Include"
export MPI_INCLUDE="$LIBS_HOME/MPI/Include -I$LIBS_HOME/MPI/Include/x64/"
export MPI_LIB=$LIBS_HOME/MPI/Lib/x86
export LIBMPI="-lmsmpifec -lmsmpi"
export BLASOPT="-L$LIBS_HOME/OpenBLAS -lopenblas"
export LAPACK_LIB="$BLASOPT"
env|egrep LAPACK
export USE_NOIO=1

make nwchem_config NWCHEM_MODULES=nwdft\ driver\ solvation\ vib\ property
sh ../../libs/scripts/doit.sh
cp ../../libs/dll/*dll ../bin/LINUX/.
mv ../bin/LINUX/nwchem  ../bin/LINUX/nwchem.exe

