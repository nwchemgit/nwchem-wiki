 curl -LJO https://github.com/nwchemgit/nwchem/tarball/hotfix/release-7-0-0
tar xzf nwchemgit-nwchem-v7.0.0-release-*-*.tar.gz
mv nwchemgit-nwchem-??????? nwchem-7.0.1
cd nwchem-7.0.1/src
  cd nwchem-7.0.1/src
  source ../../libs/scripts/nwchem.bashrc
  make nwchem_config NWCHEM_MODULES=nwdft\ driver\ solvation\ vib\ property
sh ../../libs/scripts/doit.sh


