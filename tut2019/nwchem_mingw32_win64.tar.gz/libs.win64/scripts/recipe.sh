#!/bin/bash
curl -LJO https://github.com/nwchemgit/nwchem/tarball/hotfix/release-7-0-0
tar xzf nwchemgit-nwchem-v7.0.0-release-*-*.tar.gz
mv nwchemgit-nwchem-??????? nwchem-7.0.1
export NWCHEM_TOP=`pwd`/nwchem-7.0.1 
export LIBS_HOME=`pwd`/libs.win64
 cd nwchem-7.0.1/src
export USE_MPI=1
export ARMCI_NETWORK=MPI-TS
export FC=x86_64-w64-mingw32.static-gfortran
export CC=x86_64-w64-mingw32.static-gcc
export CXX=x86_64-w64-mingw32.static-g++
export FC=x86_64-w64-mingw32-gfortran-win32
export CC=x86_64-w64-mingw32-gcc-win32
export CXX=x86_64-w64-mingw32-g++-win32
export NWCHEM_TARGET=LINUX64
#export MPI_HOME=/home/edo/mxe/intelmpi
export MPI_LIB="$LIBS_HOME"/intelmpi/lib\ -L"$LIBS_HOME"/intelmpi/lib/release
#export MPI_LIB="/home/edo/mxe/intelmpi/lib -L/home/edo/mxe/intelmpi/lib/release"
export MPI_INCLUDE="$LIBS_HOME"/intelmpi/include
export LIBMPI="-limpi"
export USE_NOIO=1
export BLAS_SIZE=4
export BLASOPT="-L$LIBS_HOME/OpenBLAS -lopenblas"
export LAPACK_LIB="$BLASOPT"
make nwchem_config NWCHEM_MODULES=all
make 64_to_32
  sh "$LIBS_HOME"/scripts/doit_x86_64.sh
cp "$LIBS_HOME"/dll/*dll ../bin/LINUX64/.
mv ../bin/LINUX64/nwchem  ../bin/LINUX64/nwchem.exe
cd ../bin/LINUX64
echo 'all files needed to run NWChem are in' `pwd`

  


