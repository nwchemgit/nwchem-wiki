make MAYBE_HOST="--host=x86_64-w64-mingw32.static" CC=x86_64-w64-mingw32-gcc-win32 FC=x86_64-w64-mingw32-gfortran-win32 V=1 -j3 GOTMINGW64=1

